<?php $this->layout('_theme') ?>


<br>
<div>
  <h1>NotFound <?=$this->e($error)?> </h1>
</div>
<br>